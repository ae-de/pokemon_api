package unam.diplomado.pokemon.pokemonservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PokemonServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
