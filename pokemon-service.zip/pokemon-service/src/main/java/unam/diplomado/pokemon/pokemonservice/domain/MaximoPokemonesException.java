package unam.diplomado.pokemon.pokemonservice.domain;

public class MaximoPokemonesException extends RuntimeException {

    public MaximoPokemonesException(String message) {
        super(message);
    }
}
